<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<div class="hp-offer__text">
	<?php comment_text( $offer->get_id() ); ?>
</div>
