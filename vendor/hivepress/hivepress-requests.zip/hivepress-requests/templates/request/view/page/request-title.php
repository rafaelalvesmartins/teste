<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<h1 class="hp-listing__title"><?php echo esc_html( $request->get_title() ); ?></h1>
